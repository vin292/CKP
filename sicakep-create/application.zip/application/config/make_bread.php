<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

//$config['include_home'] = 'Beranda';
$config['divider'] = '&nbsp;&#8250;&nbsp;';
$config['container_open'] = '<div id="breadcrumb" style="height:20px; font-size:12px; padding:5px 15px; margin-bottom:20px;">';
$config['container_close'] = '</div>';
$config['crumb_open'] = '';
$config['crumb_close'] = '';
