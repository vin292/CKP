<section id="features" class="section" style="padding-top:10px">
        <div class="container">
			<div class="alert alert-warning" role="alert">
              <strong>Perhatian!</strong> Jika menemukan anomali pada sistem ini, harap untuk segera memberitahukan admin.
            </div>
          <div class="row text-center-mobile"> 
            <div class="col-md-6">
              <div class="icon"><i class="pe-7s-wristwatch"></i></div>
              <h2>Sistem Informasi Capaian Kinerja Pegawai</h2>
              <p>mengukur hasil kerja secara kualitas dan kuantitas yang dicapai oleh seorang pegawai dalam melaksanakan fungsinya sesuai dengan tanggung jawab yang diberikan kepadanya menuju instansi yang berbasis kinerja.  </p>
            </div>
            <div class="col-md-6">
              <p><img src="<?php echo base_url('assets/img/features1.png') ?>" class="img-responsive"></p>
            </div>
          </div>
        </div>
      </section>