<!DOCTYPE html>
<html>
  <head>
    <script src="<?=base_url();?>assets/js/jquery.js"></script>
    <script src="<?=base_url();?>assets/js/jquery-ui.min.js"></script>


    <style>
      *{-moz-box-sizing:border-box;-webkit-box-sizing:border-box;box-sizing:border-box}html,body,div,span,object,iframe,h1,h2,h3,h4,h5,h6,p,blockquote,pre,abbr,address,cite,code,del,dfn,em,img,ins,kbd,q,samp,small,strong,sub,sup,var,b,i,dl,dt,dd,ol,ul,li,fieldset,form,label,legend,caption,article,aside,canvas,details,figcaption,figure,footer,header,hgroup,menu,nav,section,summary,time,mark,audio,video{margin:0;padding:0;border:0;outline:0;vertical-align:baseline;background:transparent}article,aside,details,figcaption,figure,footer,header,hgroup,nav,section{display:block}html{font-size:16px;line-height:24px;width:100%;height:100%;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;overflow-y:scroll;overflow-x:hidden}img{vertical-align:middle;max-width:100%;height:auto;border:0;-ms-interpolation-mode:bicubic}body{min-height:100%;-webkit-font-smoothing:subpixel-antialiased}.clearfix{clear:both;zoom:1}.clearfix:before,.clearfix:after{content:&quot;\0020&quot;;display:block;height:0;visibility:hidden}.clearfix:after{clear:both}

    </style>
    <style>
 .sign.error-page-wrapper {
    font-family: 'Source Sans Pro', sans-serif;
    background-color: #179eca;
    position:relative;
  }

 .sign.error-page-wrapper .sign-container {
    width:450px;
    height:415px;
    margin:0 auto;
    position: relative;
    transform:rotate(-20deg);
    text-indent:-20px;
  }


 .sign.error-page-wrapper .sign-container .nob {
    height:44px;
    width:44px;
    border-radius: 99px;
    border:12px solid #343c3f;
    position: absolute;
    top:0px;
    left:50%;
    margin-left:-22px;
  }

 .sign.error-page-wrapper .sign-container .post {
    transition:background-color .5s linear;
    width: 190px;
    height: 15px;
    top: 71px;
    background-color: #343c3f;
  }

 .sign.error-page-wrapper .sign-container .post.left {
    position: absolute;
    transform:rotate(-30deg);
    left:35px;
  }

 .sign.error-page-wrapper .sign-container .post.right {
    position: absolute;
    transform:rotate(30deg);
    right:35px;
  }

 .sign.error-page-wrapper .sign-container .pane {
    transition:background-color .5s linear, border-color .5s linear;
    box-shadow: 0 5px 0 rgba(0,0,0,.1) inset, 5px 0 0 rgba(0,0,0,.1) inset, 15px 15px 0 rgba(0,0,0,.1);
    background-color: #fff;
    border:20px solid #343c3f;
    height:300px;
    text-align: center;
    position: absolute;
    top: 115px;
    left:0px;
    right:0px;
  }

 .sign.error-page-wrapper .sign-container .pane .headline {
    transition:color .5s linear;
    margin-top:65px;
    margin-bottom: 10px;
    font-size:54px;
    line-height:68px;
    font-weight:600;
    letter-spacing: -2px;
    text-transform: uppercase;
    color:#ffba00;
  }

 .sign.error-page-wrapper .sign-container .pane.just-header .headline {
    margin-top:100px;
  }

 .sign.error-page-wrapper .sign-container .pane .context {
    transition:color .5s linear;
    color:#ffba00;
    font-size:24px;
    line-height: 32px;
  }


  @media screen and (max-width: 500px) {
    .sign.error-page-wrapper {
      padding-top:10%;
    }
    .sign.error-page-wrapper .sign-container {
      width:280px;
      top: 0px !important;
    }
    .sign.error-page-wrapper .sign-container .post {
      width:100px;
      top:50px;
    }
    .sign.error-page-wrapper .sign-container .pane {
      top:70px;
      height:220px;
    }
    .sign.error-page-wrapper .sign-container .pane .headline {
      margin-top:20px;
      font-size:45px;
      margin-bottom: 6px;
    }
    .sign.error-page-wrapper .sign-container .pane.just-header .headline {
      margin-top: 39px;
      line-height: 55px;
    }
    .sign.error-page-wrapper .sign-container .pane .context {
      font-size:20px;
      line-height: 28px;
    }
  }




 .sign.error-page-wrapper .text-container {
    max-width:600px;
    position: absolute;
    bottom:20px;
    left:35px;
  }

 .sign.error-page-wrapper .text-container .headline {
    transition:color .5s linear;
    font-size:40px;
    line-height: 52px;
    letter-spacing: -1px;
    margin-bottom: 5px;
    color:rgba(255,255,255,.3);
  }
 .sign.error-page-wrapper .text-container .context {
    transition:color .5s linear;
    font-size:18px;
    line-height:27px;
    color:#fff;
  }
 .sign.error-page-wrapper .text-container .context p {
    margin:0;
  }
 .sign.error-page-wrapper .text-container .context p + p {
    margin-top:10px;
  }
 .sign.error-page-wrapper .buttons-container {
    margin-top: 20px;
  }

 .sign.error-page-wrapper .buttons-container a {
    transition: text-indent .2s linear, color .5s linear, border-color .5s linear;
    font-size:16px;
    text-transform: uppercase;
    text-decoration: none;
    color:#fff;
    border:2px solid white;
    border-radius: 99px;
    padding:9px 0 10px;
    width:195px;
    overflow: hidden;
    text-align:center;
    display:inline-block;
    position: relative;
  }

 .sign.error-page-wrapper .buttons-container a:hover {
    background-color:rgba(255,255,255,.1);
    text-indent: 17px;
  }

 .sign.error-page-wrapper .buttons-container a:first-child {
    margin-right:25px;
  }

 .sign.error-page-wrapper .buttons-container .fa {
    transition:left .2s ease-out;
    position: absolute;
    left:-50px;
  }

 .sign.error-page-wrapper .buttons-container .fa-warning {
    font-size:16px;
    top:14px;
  }

 .sign.error-page-wrapper .buttons-container a:hover .fa-warning {
    left:0px;
  }

 .sign.error-page-wrapper .buttons-container .fa-power-off {
    font-size:16px;
    top:14px;
  }

 .sign.error-page-wrapper .buttons-container a:hover .fa-power-off {
    left:0px;
  }

 .sign.error-page-wrapper .buttons-container .fa-home {
    font-size:18px;
    top:12px;
  }

 .sign.error-page-wrapper .buttons-container a:hover .fa-home {
    left:25px;
  }

  @media screen and (max-width: 500px) {
   .sign.error-page-wrapper .text-container {
      bottom:20px;
      left:20px;
      right:20px;
    }
   .sign.error-page-wrapper .text-container .header {
      font-size:32px;
      line-height:40px;
    }
   .sign.error-page-wrapper .text-container .context {
      font-size:15px;
      line-height: 22px;
    }
   .sign.error-page-wrapper .buttons-container {
      overflow: hidden;
    }
   .sign.error-page-wrapper .buttons-container a {
      font-size:14px;
      padding:8px 0 9px;
      width:45%;
      float:left;
      margin:0;
    }
   .sign.error-page-wrapper .buttons-container a + a {
      float:right;
    }
   .sign.error-page-wrapper .buttons-container a:hover {
      text-indent: 0px;
    }
   .sign.error-page-wrapper .buttons-container .fa {
      display:none;
    }
  }
</style>
    <style>

    .background-color {
      background-color: #179ECA !important;
    }


    .primary-text-color {
      color: #FFFFFF !important;
    }

    .secondary-text-color {
      color: #73c5df !important;
    }

    .sign-text-color {
      color: #FFBA00 !important;
    }

    .sign-frame-color {
      color: #343C3F;
    }

    .pane {
      background-color: #FFFFFF !important;
    }

    .border-button {
      color: #FFFFFF !important;
      border-color: #FFFFFF !important;
    }
    .button {
      background-color: #FFFFFF !important;
      color:  !important;
    }


</style>
  </head>
  <body class="sign error-page-wrapper background-color background-image">
    <div class="sign-container">
	<div class="nob"></div>
	<div class="post left"></div>
	<div class="post right"></div>
	<div class="pane">
		<div class="headline sign-text-color">
			404
		</div>
		<div class="context sign-text-color">
			Maaf, Halaman yang<br>
			anda cari tidak ditemukan
		</div>
	</div>
</div>
<div class="text-container">
	<div class="headline secondary-text-color">
		404
	</div>
	<div class="context primary-text-color">
		<p>
			Silakan mengklik tombol beranda untuk melanjutkan menggunakan website.<br>
			Jika anda menemukan kesalahan, sampaikan kepada kami dengan mengklik tombol hubungi kami.
		</p>
	</div>
	<div class="buttons-container">
		<a class="border-button" href="<?=base_url();?>" style="border-radius:0px"><span class="fa fa-home"></span> Beranda</a>
	</div>
</div>

    <script>
      function ErrorPage(e,t,n){this.$container=$(e),this.$contentContainer=this.$container.find(n=="sign"?".sign-container":".content-container"),this.pageType=t,this.templateName=n}ErrorPage.prototype.centerContent=function(){var e=this.$container.outerHeight(),t=this.$contentContainer.outerHeight(),n=(e-t)/2,r=this.templateName=="sign"?-100:0;this.$contentContainer.css("top",n+r)},ErrorPage.prototype.initialize=function(){var e=this;this.centerContent(),this.$container.on("resize",function(t){t.preventDefault(),t.stopPropagation(),e.centerContent()}),this.templateName=="plain"&&window.setTimeout(function(){e.$contentContainer.addClass("in")},500),this.templateName=="sign"&&$(".sign-container").animate({textIndent:0},{step:function(e){$(this).css({transform:"rotate("+e+"deg)","transform-origin":"top center"})},duration:1e3,easing:"easeOutBounce"})},ErrorPage.prototype.createTimeRangeTag=function(e,t){return"<time utime="+e+' simple_format="MMM DD, YYYY HH:mm">'+e+"</time> - <time utime="+t+' simple_format="MMM DD, YYYY HH:mm">'+t+"</time>."},ErrorPage.prototype.handleStatusFetchSuccess=function(e,t){if(e=="503")$("#replace-with-fetched-data").html(t.status.description);else if(!t.scheduled_maintenances.length)$("#replace-with-fetched-data").html("<em>(there are no active scheduled maintenances)</em>");else{var n=t.scheduled_maintenances[0];$("#replace-with-fetched-data").html(this.createTimeRangeTag(n.scheduled_for,n.scheduled_until)),$.fn.localizeTime()}},ErrorPage.prototype.handleStatusFetchFail=function(e){$("#replace-with-fetched-data").html("<em>(enter a valid StatusPage.io url)</em>")},ErrorPage.prototype.fetchStatus=function(e,t){if(!e||!t||t=="404")return;var n="",r=this;t=="503"?n=e+"/api/v2/status.json":n=e+"/api/v2/scheduled-maintenances/active.json",$.ajax({type:"GET",url:n}).success(function(e,n){r.handleStatusFetchSuccess(t,e)}).fail(function(e,n){r.handleStatusFetchFail(t)})};
      var ep = new ErrorPage('body', "404", "sign");
      ep.initialize();

      $(window).on('resize', function() {
        $('body').trigger('resize')
      });

    </script>


  </body>
</html>
