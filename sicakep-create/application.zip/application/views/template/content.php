<div class="ukuran_layar">
<?php
  $this->load->view($page);
?>
</div>